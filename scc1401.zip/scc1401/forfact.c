main()
{
	int i, f = 1;
	for (i = 6; i; i-=1) {
		f *= i;
	}
}
