#include <nonstdlib.h>
int main() {
	putchar('C');
	putchar('\n');
}
