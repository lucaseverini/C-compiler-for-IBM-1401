package retree.statement;

public class EmptyStatement implements Statement{
	public String generateCode() {
		return "";
	}
}
