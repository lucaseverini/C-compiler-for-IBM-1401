package retree.statement;

public interface Statement {
	public String generateCode();
}
