int f = 1;

int main()
{
	int n = 6;
	while (n) {
		f *= n;
		n -= 1;
	}

}
