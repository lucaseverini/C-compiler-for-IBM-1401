#include <nonstdlib.h>

int main() {
	/*
	char *tmp = "fail whale\n";
	char c;
	c = getchar();
	printf("%c\n",c);
	printf("%c testing %s\n",'f',tmp);
	c = getchar();
	printf("%c\n",c);*/
	/*char s[6];
	char *t;
	int a = 5120;
	t = itoa(a,s,10);
	printf("%s\n",t);*/
	printf("%d\n",-52);
}

